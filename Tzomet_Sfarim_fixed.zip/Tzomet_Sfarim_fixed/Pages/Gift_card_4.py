import random

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Basepage import BasePage


class GiftCard4(BasePage):
    GIFT_CARD_BUTTON = (By.LINK_TEXT, "כרטיס מתנה")
    DIGITAL_GIFT_CARD = (By.CSS_SELECTOR, "img[src*='de0935f2-16f9-4c34-add9-2961654394b0']")
    GIFT_SUM = (By.CSS_SELECTOR, ".mat-input-element")
    START_BUTTON = (By.CSS_SELECTOR, "button.mat-focus-indicator.bigButton")
    NAME_INPUT = (By.ID, "mat-input-1")
    EVENT_SELECT = (By.ID, "mat-select-value-1")
    BLESSING_INPUT = (By.CSS_SELECTOR, ".mat-input-element")
    CONTINUE_BUTTON = (By.XPATH, "//button[.//span[text()='המשך']]")
    SMS_BUTTON = (By.XPATH, '//button[.//mat-icon[normalize-space()="stay_current_portrait"]]')
    EMAIL_BUTTON = (By.XPATH, '//button[.//mat-icon[normalize-space()="mail_outline"]]')
    PHONE_RECEIVER = (By.CSS_SELECTOR, 'input[formcontrolname="phoneNumber"]')
    EMAIL_RECEIVER = (By.CSS_SELECTOR, 'input[formcontrolname="email"]')
    NAME_SENDER = (By.CSS_SELECTOR, 'input[formcontrolname="PayFName"]')
    PHONE_SENDER = (By.CSS_SELECTOR, 'input[formcontrolname="phoneSender"]')
    EMAIL_SENDER = (By.CSS_SELECTOR, 'input[formcontrolname="mailSender"]')
    GO_TO_PAYMENT_BUTTON = (By.ID, "goToPaymentButton")

    def wait_for_gift_card_button(self):
        """Wait for the 'Gift Card' button to be present in DOM"""
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.GIFT_CARD_BUTTON)
        )

    def click_gift_card_button(self):
        self.wait_for_gift_card_button()
        button = self.find_element(self.GIFT_CARD_BUTTON)
        self.driver.execute_script("arguments[0].click();", button)

    def click_gift_card_image(self):
        """Wait for image visibility and click"""
        element = self.driver.find_element(*self.DIGITAL_GIFT_CARD)
        self.driver.execute_script("arguments[0].click();", element)

    def type_random_gift_sum(self):
        # Wait for the element to be visible
        gift_sum_input = WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, ".mat-input-element"))
        )

        # Clear any pre-filled value
        gift_sum_input.clear()

        # Generate a random sum between 50 and 1000
        value = random.randint(50, 1000)

        # Type the random sum into the input field using JavaScript
        self.driver.execute_script(
            "arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('input', { bubbles: true }));",
            gift_sum_input, value)

        print(f"Typed sum: {value}")

    def click_start_button(self):
        # Wait for the button to be clickable
        start_button = WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.START_BUTTON)
        )

        # Click the button using JavaScript for robustness
        self.driver.execute_script("arguments[0].click();", start_button)

        print("Clicked the 'בואו נתחיל' button.")

    def type_random_name(self):
        # Random Hebrew names list
        names = ["יוסי", "מרים", "דוד", "רבקה", "שרה", "יוחנן", "אסתר", "נחמה", "אביגיל", "מאור"]

        # Choose a random name
        random_name = random.choice(names)

        # Locate the input field and clear any pre-filled value
        name_input = self.driver.find_element(*self.NAME_INPUT)
        name_input.clear()

        # Type the random name into the input field
        name_input.send_keys(random_name)

        print(f"Typed random name: {random_name}")

    def select_random_event(self):
        # Click the mat-select element to open the dropdown
        event_select = self.driver.find_element(*self.EVENT_SELECT)
        event_select.click()

        # Wait for the options to load and become visible
        WebDriverWait(self.driver, 10).until(
            EC.visibility_of_all_elements_located((By.CSS_SELECTOR, "mat-option"))
        )

        # Find all the available mat-option elements
        event_options = self.driver.find_elements(By.CSS_SELECTOR, "mat-option")

        # Choose a random option from the available options
        random_option = random.choice(event_options)

        # Click on the random option
        random_option.click()

        # Print the selected option's text (the event name)
        print(f"Selected event: {random_option.text.strip()}")

    def type_random_blessing(self):
        # Dictionary to map events to their respective blessings
        blessings = {
            "יום הולדת": "מזל טוב, אהבה ואושר!",
            "לידה": "לידה קלה ומהירה!",
            "תודה": "תודה רבה על הכול!",
            "פרידה": "למרות הקושי, אוהבים ומאחלים הצלחה בדרך החדשה!",
            "חתונה": "אושר ואהבה בחיים החדשים!",
            "חינה": "עוד קצת וחתונה, אוהבים!",
            "סתם כי בא לי לפנק": "מגיע לך!",
            "כניסה לבית חדש": "ימים יפים בכל יום, שלווה ושקט בביתך!",
            "יום נישואין": "עוד שנים יפות לאהבה, מזל טוב!",
            "בהצלחה": "הצלחה בכל הטוב!",
            "מתנות לעובדים": "מגיע לכם, עבודה נהדרת!",
            "בר מצווה": "גיל מיוחד, מילדות לנערות, אושר וימים מאושרים!",
            "בת מצווה": "גיל מיוחד, מילדות לנערות, אושר וימים מאושרים!"
        }

        # Get the selected event (which has already been chosen by the user)
        # You can get the selected event text (in case it's saved or can be accessed directly)
        selected_event = self.driver.find_element(By.CSS_SELECTOR, ".mat-select-value-text").text.strip()

        # Get the corresponding blessing
        blessing = blessings.get(selected_event, "ברכה כללית")  # Default blessing in case no match

        # Wait for the blessing input to be visible
        blessing_input = WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.BLESSING_INPUT)
        )

        # Clear any existing text in the blessing input field
        blessing_input.clear()

        # Type the selected blessing in the input field
        blessing_input.send_keys(blessing)

        # Print the blessing to confirm
        print(f"Typed blessing: {blessing}")

    def click_continue_button(self):
        # Find the continue button and click it
        continue_button = self.driver.find_element(*self.CONTINUE_BUTTON)
        continue_button.click()
        print("Clicked on 'המשך' button")

        # --- JS Click for Angular buttons ---

    def js_click_local(self, locator):
        element = self.driver.find_element(*locator)
        self.driver.execute_script("arguments[0].click();", element)

    def click_sms(self):
        elem = self.driver.find_element(*self.SMS_BUTTON)
        self.driver.execute_script("arguments[0].scrollIntoView(true); arguments[0].click();", elem)
        print("Clicked SMS button (JS + scroll)")

    def click_email(self):
        elem = self.driver.find_element(*self.EMAIL_BUTTON)
        self.driver.execute_script("arguments[0].scrollIntoView(true); arguments[0].click();", elem)
        print("Clicked Email button (JS + scroll)")

    # --- inside GiftCard4 class ---

    # --- Methods ---
    def type_receiver_phone(self, phone):
        # Wait until element exists in DOM
        WebDriverWait(self.driver, 10).until(
            lambda d: d.find_element(*self.PHONE_RECEIVER)
        )
        elem = self.driver.find_element(*self.PHONE_RECEIVER)
        # JS type to avoid interactable issues
        self.driver.execute_script("arguments[0].value = arguments[1];", elem, phone)
        print(f"Typed recipient phone (JS): {phone}")

    def type_receiver_email(self, email):
        elem = self.driver.find_element(*self.EMAIL_RECEIVER)
        self.driver.execute_script("arguments[0].value = arguments[1];", elem, email)
        print(f"Typed recipient email (JS): {email}")

    def type_sender_name(self, name):
        elem = self.driver.find_element(*self.NAME_SENDER)
        self.driver.execute_script("arguments[0].value = arguments[1];", elem, name)
        print(f"Typed sender name (JS): {name}")


    def type_sender_phone(self, phone):
        elem = self.driver.find_element(*self.PHONE_SENDER)
        elem.clear()
        elem.send_keys(phone)
        print(f"Typed sender phone: {phone}")

    def type_sender_email(self, email):
        elem = self.driver.find_element(*self.EMAIL_SENDER)
        elem.clear()
        elem.send_keys(email)
        print(f"Typed sender email: {email}")

    def click_go_to_payment(self):
        elem = self.driver.find_element(*self.GO_TO_PAYMENT_BUTTON)
        self.driver.execute_script("arguments[0].scrollIntoView(true); arguments[0].click();", elem)
        print("Clicked 'המשך לתשלום' button (JS + scroll)")
