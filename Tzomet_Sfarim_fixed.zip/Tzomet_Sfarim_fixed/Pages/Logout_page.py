from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Basepage import BasePage

class LogoutPage(BasePage):
    LOGOUT_BUTTON = (By.XPATH, "//button[@class='link logout-open' and text()='התנתקות']")

    def logout(self):
        """Click the logout button."""
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.LOGOUT_BUTTON)
        )
        self.click(*self.LOGOUT_BUTTON)
