from selenium.webdriver.common.by import By
from Pages.Basepage import BasePage
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class LoginPage(BasePage):
    LOGIN_LINK = (By.XPATH, "//span[text()='הרשמה / כניסה']")
    EMAIL_INPUT = (By.NAME, "userEmail")
    PASSWORD_INPUT = (By.NAME, "userPassword")
    LOGIN_BUTTON = (By.XPATH, "//input[@type='submit' and @value='התחברות']")  # updated to match the submit input

    def __init__(self, driver):
        super().__init__(driver)
        self.enter_website("https://www.booknet.co.il/")
        self.click_agree_button()

    def open_login(self):
        """Click the login link."""
        self.click(*self.LOGIN_LINK)

    def login(self, email, password):
        """Enter credentials and submit the login form."""
        WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.EMAIL_INPUT)
        )
        self.find_element(*self.EMAIL_INPUT).send_keys(email)
        self.find_element(*self.PASSWORD_INPUT).send_keys(password)
        # wait until the login button is clickable
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.LOGIN_BUTTON)
        )
        self.click(*self.LOGIN_BUTTON)
