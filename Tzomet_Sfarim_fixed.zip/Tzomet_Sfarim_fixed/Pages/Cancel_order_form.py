from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Basepage import BasePage


class CancelOrderPage(BasePage):
    CANCEL_ORDER_LINK = (By.XPATH, '//*[@id="header-inner-row-2"]/ul[2]/li[1]/a')

    NAME_INPUT = (By.ID, "name")
    EMAIL_INPUT = (By.ID, "mail")
    PHONE_INPUT = (By.ID, "phone")
    ORDER_INPUT = (By.ID, "message")
    SEND_BUTTON = (By.ID, "send-contactus")

    def click_cancel_order(self):
        """Click the 'Cancel Order' link using JavaScript."""
        # Wait until the link is visible
        WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.CANCEL_ORDER_LINK)
        )

        # Find the element and click with JS
        cancel_link_element = self.driver.find_element(*self.CANCEL_ORDER_LINK)
        self.driver.execute_script("arguments[0].click();", cancel_link_element)
        print("Clicked 'Cancel Order' link using JavaScript.")

    def fill_cancel_form(self):
        """Detect all input fields and the send button without sending anything."""
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.NAME_INPUT)
        )

        print("\n--- Cancel Order Form ---")
        print("Name field found:", self.driver.find_element(*self.NAME_INPUT).get_attribute("name"))
        print("Email field found:", self.driver.find_element(*self.EMAIL_INPUT).get_attribute("name"))
        print("Phone field found:", self.driver.find_element(*self.PHONE_INPUT).get_attribute("name"))
        print("Order number field found:", self.driver.find_element(*self.ORDER_INPUT).get_attribute("name"))

        send_btn = self.driver.find_element(*self.SEND_BUTTON)
        print("Send button found:", send_btn.get_attribute("id"))
