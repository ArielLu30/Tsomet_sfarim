from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Basepage import BasePage

class ContactUsPage(BasePage):
    CONTACT_LINK = (By.LINK_TEXT, "צור קשר")
    NAME_INPUT = (By.ID, "name")
    EMAIL_INPUT = (By.ID, "mail")
    PHONE_INPUT = (By.ID, "phone")
    SUBJECT_INPUT = (By.ID, "subject")
    MESSAGE_INPUT = (By.ID, "message")
    SEND_BUTTON = (By.ID, "send-contactus")

    def click_contact_link(self):
        """Click the 'צור קשר' link using JavaScript."""
        WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.CONTACT_LINK)
        )
        link = self.driver.find_element(*self.CONTACT_LINK)
        self.driver.execute_script("arguments[0].click();", link)
        print("Clicked 'צור קשר' link using JavaScript.")

    def fill_contact_form(self, name="", email="", phone="", subject="", message=""):
        """Fill the Contact Us form with provided details (do not click send)."""
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.NAME_INPUT)
        )

        self.driver.find_element(*self.NAME_INPUT).send_keys(name)
        self.driver.find_element(*self.EMAIL_INPUT).send_keys(email)
        self.driver.find_element(*self.PHONE_INPUT).send_keys(phone)
        self.driver.find_element(*self.SUBJECT_INPUT).send_keys(subject)
        self.driver.find_element(*self.MESSAGE_INPUT).send_keys(message)


        self.driver.find_element(*self.NAME_INPUT).get_attribute("name")
        self.driver.find_element(*self.EMAIL_INPUT).get_attribute("name")
        self.driver.find_element(*self.PHONE_INPUT).get_attribute("name")
        self.driver.find_element(*self.SUBJECT_INPUT).get_attribute("name")
        self.driver.find_element(*self.MESSAGE_INPUT).get_attribute("name")
        self.driver.find_element(*self.SEND_BUTTON)

        # Now print the actual values typed

        print("--- Contact Us Form ---")
        print("Name:", self.driver.find_element(*self.NAME_INPUT).get_attribute("value"))
        print("Email:", self.driver.find_element(*self.EMAIL_INPUT).get_attribute("value"))
        print("Phone:", self.driver.find_element(*self.PHONE_INPUT).get_attribute("value"))
        print("Subject:", self.driver.find_element(*self.SUBJECT_INPUT).get_attribute("value"))
        print("Message:", self.driver.find_element(*self.MESSAGE_INPUT).get_attribute("value"))
        print("Form filled in but not sent")
