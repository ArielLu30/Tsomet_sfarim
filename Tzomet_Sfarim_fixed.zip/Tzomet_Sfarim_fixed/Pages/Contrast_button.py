from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Basepage import BasePage

class ContrastPage(BasePage):
    CONTRAST_BUTTON = (By.XPATH, "//button[@aria-label='שנה ניגודיות' and text()='ניגודיות']")

    def wait_for_contrast_button(self):
        """Wait for the 'ניגודיות' button to be present in the DOM."""
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.CONTRAST_BUTTON)
        )

    def click_contrast(self):
        """Click the 'ניגודיות' button using JavaScript."""
        self.wait_for_contrast_button()
        button = self.find(*self.CONTRAST_BUTTON)
        self.driver.execute_script("arguments[0].click();", button)
        print("Clicked 'ניגודיות' button.")
