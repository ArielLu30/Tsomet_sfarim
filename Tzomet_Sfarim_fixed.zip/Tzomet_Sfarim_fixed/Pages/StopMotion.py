from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Basepage import BasePage

class StopMovementPage(BasePage):
    PAUSE_BUTTON = (By.ID, "pauseButton")

    def wait_for_pause_button(self):
        """Wait for the 'עצירת תנועה' button to be present in the DOM."""
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.PAUSE_BUTTON)
        )

    def click_pause(self):
        """Click the 'עצירת תנועה' button using JavaScript."""
        self.wait_for_pause_button()
        button = self.find(*self.PAUSE_BUTTON)
        self.driver.execute_script("arguments[0].click();", button)
        print("Clicked 'עצירת תנועה' button.")
