import random

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Basepage import BasePage


class GiftCard2(BasePage):
    GIFT_CARD_BUTTON = (By.LINK_TEXT, "כרטיס מתנה")
    DIGITAL_GIFT_CARD = (By.CSS_SELECTOR, "img[src*='de0935f2-16f9-4c34-add9-2961654394b0']")
    GIFT_SUM = (By.CSS_SELECTOR, ".mat-input-element")
    START_BUTTON = (By.CSS_SELECTOR, "button.mat-focus-indicator.bigButton")

    def wait_for_gift_card_button(self):
        """Wait for the 'Gift Card' button to be present in DOM"""
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.GIFT_CARD_BUTTON)
        )

    def click_gift_card_button(self):
        self.wait_for_gift_card_button()
        button = self.find_element(self.GIFT_CARD_BUTTON)
        self.driver.execute_script("arguments[0].click();", button)

    def click_gift_card_image(self):
        """Wait for image visibility and click"""
        element = self.driver.find_element(*self.DIGITAL_GIFT_CARD)
        self.driver.execute_script("arguments[0].click();", element)

    def type_random_gift_sum(self):
        # Wait for the element to be visible
        gift_sum_input = WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, ".mat-input-element"))
        )

        # Clear any pre-filled value
        gift_sum_input.clear()

        # Generate a random sum between 50 and 1000
        value = random.randint(50, 1000)

        # Type the random sum into the input field using JavaScript
        self.driver.execute_script(
            "arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('input', { bubbles: true }));",
            gift_sum_input, value)

        print(f"Typed sum: {value}")

    def click_start_button(self):
        # Wait for the button to be clickable
        start_button = WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.START_BUTTON)
        )

        # Click the button using JavaScript for robustness
        self.driver.execute_script("arguments[0].click();", start_button)

        print("Clicked the 'בואו נתחיל' button.")
