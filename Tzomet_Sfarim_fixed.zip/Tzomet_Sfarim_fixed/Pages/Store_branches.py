import random
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Basepage import BasePage

class BranchesPage(BasePage):

    BRANCHES_LINK = (By.LINK_TEXT, "סניפים")
    CITY_DROPDOWN = (By.ID, "city")
    CITY_DROPDOWN_OPTIONS = (By.CSS_SELECTOR, "#city option")
    SELECTED_CITY = (By.CSS_SELECTOR, "#city option:checked")

    def open_branches(self):
        """Click the 'סניפים' link using JavaScript."""
        self.wait_for_element_visible(*self.BRANCHES_LINK)
        branches_link = self.find(*self.BRANCHES_LINK)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", branches_link)
        self.driver.execute_script("arguments[0].click();", branches_link)
        print("Branches link clicked using JavaScript.")

    def click_random_city(self):
        """Click a random city option from the city dropdown normally."""
        # Wait for the dropdown to be visible and clickable
        self.wait_for_element_visible(*self.CITY_DROPDOWN)
        dropdown = self.find(*self.CITY_DROPDOWN)

        # Click the dropdown to open the options
        dropdown.click()

        # Wait for the options to be present in the DOM
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_all_elements_located(self.CITY_DROPDOWN_OPTIONS)
        )

        # Get all options
        cities = self.find_all(*self.CITY_DROPDOWN_OPTIONS)

        if cities:
            # Exclude the first option if it's "כל הסניפים"
            selectable = cities[1:] if cities[0].text.strip() == "כל הסניפים" else cities

            # Pick a random option
            choice = random.choice(selectable)

            # Click the random city
            choice.click()

            print(f"Random city clicked: {choice.text.strip()}")

    def print_selected_city(self):
        """Print the currently selected city from the dropdown."""
        self.wait_for_element_visible(*self.SELECTED_CITY)
        selected = self.find(*self.SELECTED_CITY)
        print(f"Selected city: {selected.text.strip()}")
