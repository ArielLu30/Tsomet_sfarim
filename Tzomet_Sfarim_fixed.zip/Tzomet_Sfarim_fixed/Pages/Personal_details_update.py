from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Personal_details import PersonalAreaPage


class EditPersonalDetailsPage(PersonalAreaPage):
    SAVE_BUTTON = (By.XPATH, '//*[@id="profile-page-container"]/div[2]/div[1]/div/button[1]')

    def update_personal_details(
        self,
        first_name=None,
        last_name=None,
        email=None,
        street=None,
        street_number=None,
        city=None,
        zip_code=None,
        country=None,
        phone=None
    ):
        """Update personal details. Only fields passed will be changed."""

        # ensure we are in personal area
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.FIRST_NAME)
        )

        def set_value(locator, value):
            if value is not None:
                field = self.driver.find_element(*locator)
                field.clear()
                field.send_keys(value)

        set_value(self.FIRST_NAME, first_name)
        set_value(self.LAST_NAME, last_name)
        set_value(self.EMAIL, email)
        set_value(self.STREET, street)
        set_value(self.STREET_NUMBER, street_number)
        set_value(self.CITY, city)
        set_value(self.ZIP, zip_code)
        set_value(self.COUNTRY, country)
        set_value(self.PHONE, phone)

    def verify_save_button_and_print_details(self):
        """Verify save button exists and print updated personal details."""

        # just verify save button is present
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.SAVE_BUTTON)
        )

        print("\nSave button found ✔")

        # reprint updated personal details
        print("\n--- Updated Personal Details ---")
        print("First name:", self.driver.find_element(*self.FIRST_NAME).get_attribute("value"))
        print("Last name:", self.driver.find_element(*self.LAST_NAME).get_attribute("value"))
        print("Email:", self.driver.find_element(*self.EMAIL).get_attribute("value"))
        print("Street:", self.driver.find_element(*self.STREET).get_attribute("value"))
        print("Street number:", self.driver.find_element(*self.STREET_NUMBER).get_attribute("value"))
        print("City:", self.driver.find_element(*self.CITY).get_attribute("value"))
        print("Zip code:", self.driver.find_element(*self.ZIP).get_attribute("value"))
        print("Country:", self.driver.find_element(*self.COUNTRY).get_attribute("value"))
        print("Phone:", self.driver.find_element(*self.PHONE).get_attribute("value"))
