from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Login_page import LoginPage


class PersonalAreaPage(LoginPage):
    PERSONAL_AREA_LINK = (By.LINK_TEXT, "לאזור האישי")

    FIRST_NAME = (By.ID, "customer-firstname")
    LAST_NAME = (By.ID, "customer-lastname")
    EMAIL = (By.ID, "customer-email")
    STREET = (By.ID, "customer-street")
    STREET_NUMBER = (By.ID, "customer-homenum")
    CITY = (By.ID, "customer-city")
    ZIP = (By.ID, "customer-zip")
    COUNTRY = (By.ID, "customer-country")
    PHONE = (By.ID, "customer-phone")

    def print_personal_details(self):
        # click "לאזור האישי"
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.PERSONAL_AREA_LINK)
        )
        self.click(*self.PERSONAL_AREA_LINK)

        # wait until details are loaded
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.FIRST_NAME)
        )

        print("\n--- Personal Details ---")
        print("First name:", self.driver.find_element(*self.FIRST_NAME).get_attribute("value"))
        print("Last name:", self.driver.find_element(*self.LAST_NAME).get_attribute("value"))
        print("Email:", self.driver.find_element(*self.EMAIL).get_attribute("value"))
        print("Street:", self.driver.find_element(*self.STREET).get_attribute("value"))
        print("Street number:", self.driver.find_element(*self.STREET_NUMBER).get_attribute("value"))
        print("City:", self.driver.find_element(*self.CITY).get_attribute("value"))
        print("Zip code:", self.driver.find_element(*self.ZIP).get_attribute("value"))
        print("Country:", self.driver.find_element(*self.COUNTRY).get_attribute("value"))
        print("Phone:", self.driver.find_element(*self.PHONE).get_attribute("value"))
