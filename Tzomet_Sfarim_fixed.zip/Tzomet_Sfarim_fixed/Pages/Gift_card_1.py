from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Pages.Basepage import BasePage


class GiftCard1(BasePage):

    GIFT_CARD_BUTTON = (By.LINK_TEXT, "כרטיס מתנה")
    DIGITAL_GIFT_CARD = (By.CSS_SELECTOR, "img[src*='de0935f2-16f9-4c34-add9-2961654394b0']")


    def wait_for_gift_card_button(self):
        """Wait for the 'Gift Card' button to be present in DOM"""
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.GIFT_CARD_BUTTON)
        )

    def click_gift_card_button(self):
        self.wait_for_gift_card_button()
        button = self.find_element(self.GIFT_CARD_BUTTON)
        self.driver.execute_script("arguments[0].click();", button)

    def click_gift_card_image(self):
        """Wait for image visibility and click"""
        element = self.driver.find_element(*self.DIGITAL_GIFT_CARD)
        self.driver.execute_script("arguments[0].click();", element)
