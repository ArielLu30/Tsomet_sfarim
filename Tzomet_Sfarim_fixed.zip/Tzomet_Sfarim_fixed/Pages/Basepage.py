from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException
from selenium.common.exceptions import NoSuchElementException, TimeoutException, ElementClickInterceptedException

class BasePage:

    def __init__(self, driver, timeout=10):
        self.driver = driver
        self.wait = WebDriverWait(self.driver, timeout)  # <-- define self.wait

    def enter_website(self, url):
        """Navigate to the given URL and maximize the window."""
        self.driver.get("https://www.booknet.co.il/")
        self.driver.maximize_window()

    def find_element(self, locator):
        return self.driver.find_element(*locator)

    def find(self, by, value):
        return self.driver.find_element(by, value)

    def click(self, by, value):
        """Generic click method for any element."""
        element = self.find_element(by, value)
        element.click()

    def click_agree_button(self):
        """Click the 'אני מסכים' button if it appears."""
        agree_xpath = '//*[@id="cookies-policy-modal"]/div[2]/div/div/div[2]/button[1]'
        try:
            button = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, agree_xpath))
            )
            self.driver.execute_script("arguments[0].scrollIntoView(true);", button)
            button.click()
        except (TimeoutException, ElementClickInterceptedException):
            # modal not present or already closed, safe to ignore
            pass

    def wait_for_element_visible(self, by, value, timeout=10):
            return WebDriverWait(self.driver, timeout).until(
                EC.visibility_of_element_located((by, value))
            )

    def find_all(self, by, value):
            return self.driver.find_elements(by, value)

    def wait_for_element_present(self, by, value):
        """Wait until element exists in DOM (not necessarily visible)."""
        return self.wait.until(EC.presence_of_element_located((by, value)))

    def wait_for_element_visible(self, by, value):
        """Wait until element is visible to user."""
        return self.wait.until(EC.visibility_of_element_located((by, value)))

    def wait_for_element_clickable(self, by, value):
        """Wait until element is clickable."""
        return self.wait.until(EC.element_to_be_clickable((by, value)))

        # The default wait method used by pages

    def wait_for_element(self, by, value):
        """Simplest and most used: wait for visibility."""
        return self.wait_for_element_visible(by, value)

        # -------------------------
        # ACTION HELPERS
        # -------------------------

    def click(self, by, value):
        """Wait and click element."""
        element = self.wait_for_element_clickable(by, value)
        element.click()

    def type(self, by, value, text):
        """Wait and type text into input field."""
        element = self.wait_for_element_visible(by, value)
        element.clear()
        element.send_keys(text)

    def get_text(self, by, value):
        """Wait and get visible text."""
        return self.wait_for_element_visible(by, value).text

    def find(self, by, value):
        """Find a single element (no waiting)."""
        return self.driver.find_element(by, value)

    def find_all(self, by, value):
        """Find multiple elements (no waiting)."""
        return self.driver.find_elements(by, value)

        # -------------------------
        # UTILITY
        # -------------------------

    def element_exists(self, by, value):
        """Return True if element exists in DOM."""
        try:
            self.driver.find_element(by, value)
            return True
        except NoSuchElementException:
            return False

    def safe_get_text(self, by, value):
        """Return text or empty string if not found."""
        try:
            return self.driver.find_element(by, value).text
        except:
            return ""

    def scroll_into_view(self, by, value):
        """Scroll until the element is visible."""
        element = self.wait_for_element_visible(by, value)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        return element

    def js_click(self, by, value):
        element = self.find(by, value)
        self.driver.execute_script("arguments[0].click();", element)