from Pages.Personal_details import PersonalAreaPage

def test_go_to_personal_area(driver):
    page = PersonalAreaPage(driver)
    page.open_login()
    page.login("ariellu30@gmail.com", "linusadQ12")
    page.print_personal_details()
