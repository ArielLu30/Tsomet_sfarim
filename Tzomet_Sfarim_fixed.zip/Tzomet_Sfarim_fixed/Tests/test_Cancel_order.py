from Pages.Login_page import LoginPage
from Pages.Cancel_order_form import CancelOrderPage

def test_cancel_order_form_flow(driver):
    # Step 1: Login
    login_page = LoginPage(driver)
    login_page.open_login()
    login_page.login("ariellu30@gmail.com", "linusadQ12")

    # Step 2: Open cancel order page (just detect link)
    cancel_page = CancelOrderPage(driver)
    cancel_page.click_cancel_order()

    # Step 3: Fill form (just detect input fields, do not submit)
    # Enter actual details
    cancel_page.driver.find_element(*cancel_page.NAME_INPUT).send_keys("Ariel Alex Luzzato")
    cancel_page.driver.find_element(*cancel_page.EMAIL_INPUT).send_keys("ariellu30@gmail.com")
    cancel_page.driver.find_element(*cancel_page.PHONE_INPUT).send_keys("0524808108")
    cancel_page.driver.find_element(*cancel_page.ORDER_INPUT).send_keys("123456")  # order number

    # Print what was entered
    print("\n--- Cancel Order Form Filled ---")
    print("Name entered:", cancel_page.driver.find_element(*cancel_page.NAME_INPUT).get_attribute("value"))
    print("Email entered:", cancel_page.driver.find_element(*cancel_page.EMAIL_INPUT).get_attribute("value"))
    print("Phone entered:", cancel_page.driver.find_element(*cancel_page.PHONE_INPUT).get_attribute("value"))
    print("Order number entered:", cancel_page.driver.find_element(*cancel_page.ORDER_INPUT).get_attribute("value"))

    # Detect Send button (do not click)
    send_btn = cancel_page.driver.find_element(*cancel_page.SEND_BUTTON)
    print("Send button found:", send_btn.get_attribute("id"))
