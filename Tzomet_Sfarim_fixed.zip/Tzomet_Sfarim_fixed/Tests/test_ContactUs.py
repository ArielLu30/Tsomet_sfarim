from Pages.ContactUs import ContactUsPage
from Pages.Login_page import LoginPage

def test_contact_us_form(driver):
    # Step 1: Login
    login_page = LoginPage(driver)
    login_page.open_login()
    login_page.login("ariellu30@gmail.com", "linusadQ12")

    # Step 2: Open Contact Us page
    contact_page = ContactUsPage(driver)
    contact_page.click_contact_link()

    # Step 3: Detect input fields and send button
    contact_page.fill_contact_form(
        name="Ariel Alex Luzzato",
        email="ariellu30@gmail.com",
        phone="0501234567",
        subject="Test Contact",
        message="This is a test message."
    )