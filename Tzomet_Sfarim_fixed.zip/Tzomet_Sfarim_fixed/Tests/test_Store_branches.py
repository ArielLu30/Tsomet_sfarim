from Pages.Login_page import LoginPage
from Pages.Store_branches import BranchesPage

def test_random_branch_selection(driver):
    # Step 1: Login
    login_page = LoginPage(driver)
    login_page.open_login()
    login_page.login("ariellu30@gmail.com", "linusadQ12")

    # Step 2: Open branches page and select a random city
    branches_page = BranchesPage(driver)
    branches_page.open_branches()
    branches_page.click_random_city()
    branches_page.print_selected_city()
