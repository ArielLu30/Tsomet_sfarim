from Pages.Personal_details_update import EditPersonalDetailsPage

def test_edit_personal_details(driver):
    page = EditPersonalDetailsPage(driver)

    page.open_login()
    page.login("ariellu30@gmail.com", "linusadQ12")

    page.print_personal_details()

    page.update_personal_details(
        street="הרדוף",
        street_number="24",
        city="טירת כרמל",
        zip_code="12345",
        country="Israel",
        phone="0521111111"
    )

    page.verify_save_button_and_print_details()
