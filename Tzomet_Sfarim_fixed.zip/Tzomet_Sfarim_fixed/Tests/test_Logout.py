from Pages.Login_page import LoginPage
from Pages.Logout_page import LogoutPage

def test_login_logout(driver):
    login_page = LoginPage(driver)
    login_page.open_login()
    login_page.login("ariellu30@gmail.com", "linusadQ12")

    # now logged in
    logout_page = LogoutPage(driver)
    logout_page.logout()
