from Pages.Login_page import LoginPage

def test_login(driver):
    page = LoginPage(driver)
    page.open_login()
    page.login("ariellu30@gmail.com", "linusadQ12")