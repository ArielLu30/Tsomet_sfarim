from selenium import webdriver
from Pages.Login_page import LoginPage
from Pages.Gift_card_4 import GiftCard4
from Pages.Basepage import BasePage

def test_gift_card_4():
    driver = webdriver.Chrome()

    # 1. Open page and click agree
    base_page = BasePage(driver)
    driver.get("https://www.booknet.co.il/")  # open page once
    base_page.click_agree_button()

    # 2. Gift Card actions
    gift_card_page = GiftCard4(driver)
    gift_card_page.wait_for_gift_card_button()
    gift_card_page.click_gift_card_button()
    gift_card_page.click_gift_card_image()
    gift_card_page.type_random_gift_sum()
    gift_card_page.click_start_button()
    gift_card_page.type_random_name()
    gift_card_page. select_random_event()
    gift_card_page.type_random_blessing()
    gift_card_page.click_continue_button()
    gift_card_page.click_sms()
    gift_card_page.type_receiver_phone("0500000000")
    gift_card_page.click_email()
    gift_card_page.type_receiver_email("example123@gmail.com")
    gift_card_page.type_sender_name("יוחנן")
    gift_card_page.type_sender_phone("0501234567")
    gift_card_page.type_sender_email("example@mail.com")
    gift_card_page.click_go_to_payment()

    driver.quit()
