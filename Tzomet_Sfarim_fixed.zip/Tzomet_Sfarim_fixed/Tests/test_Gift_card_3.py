from selenium import webdriver
from Pages.Login_page import LoginPage
from Pages.Gift_card_3 import GiftCard3
from Pages.Basepage import BasePage

def test_gift_card_3():
    driver = webdriver.Chrome()

    # 1. Open page and click agree
    base_page = BasePage(driver)
    driver.get("https://www.booknet.co.il/")  # open page once
    base_page.click_agree_button()

    # 2. Gift Card actions
    gift_card_page = GiftCard3(driver)
    gift_card_page.wait_for_gift_card_button()
    gift_card_page.click_gift_card_button()
    gift_card_page.click_gift_card_image()
    gift_card_page.type_random_gift_sum()
    gift_card_page.click_start_button()
    gift_card_page.type_random_name()
    gift_card_page. select_random_event()
    gift_card_page.type_random_blessing()
    gift_card_page.click_continue_button()


    driver.quit()
