from selenium import webdriver
from Pages.Login_page import LoginPage
from Pages.Contrast_button import ContrastPage
from Pages.Basepage import BasePage


def test_click_contrast():
    driver = webdriver.Chrome()

    # 1. Open page and click agree
    base_page = BasePage(driver)
    driver.get("https://www.booknet.co.il/")  # open page once
    base_page.click_agree_button()

    # 2. Login
    login_page = LoginPage(driver)
    login_page.open_login()
    login_page.login("ariellu30@gmail.com", "linusadQ13")

    # 3. Click contrast
    contrast_page = ContrastPage(driver)
    contrast_page.click_contrast()

    driver.quit()
