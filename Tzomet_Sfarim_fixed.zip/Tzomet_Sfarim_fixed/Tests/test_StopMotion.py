from selenium import webdriver
from Pages.Login_page import LoginPage
from Pages.StopMotion import StopMovementPage
from Pages.Basepage import BasePage


def test_click_pause():
    driver = webdriver.Chrome()

    # Open page and click agree
    base_page = BasePage(driver)
    driver.get("https://www.booknet.co.il/")
    base_page.click_agree_button()

    # Login
    login_page = LoginPage(driver)
    login_page.open_login()
    login_page.login("ariellu30@gmail.com", "linusadQ13")

    # Click pause
    stop_page = StopMovementPage(driver)
    stop_page.click_pause()

    driver.quit()
